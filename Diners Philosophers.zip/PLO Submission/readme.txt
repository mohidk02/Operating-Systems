1) install xming
2) use wsl
3) use bash terminal
4) copy and paste gcc test.c -o test
5) copy and paste ./test

Note: xming might crash on some PCs. 